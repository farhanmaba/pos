<?php 

$lang["enum_half_down"] = "Halv ner";
$lang["enum_half_even"] = "Halv ojämn";
$lang["enum_half_five"] = "Halv fem";
$lang["enum_half_odd"] = "Halv ojämn";
$lang["enum_half_up"] = "Halv upp";
$lang["enum_round_down"] = "Avrunda ner";
$lang["enum_round_up"] = "Avrunda upp";
