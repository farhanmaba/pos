<?php 

$lang["login_gcaptcha"] = "Jag är inte en robot.";
$lang["login_go"] = "Logga in";
$lang["login_invalid_gcaptcha"] = "Ogiltig jag är ingen robot.";
$lang["login_invalid_installation"] = "Installationen är inte korrekt, kontrollera din php.ini fil.";
$lang["login_invalid_username_and_password"] = "Ogiltigt användarnamn eller lösenord.";
$lang["login_login"] = "Login";
$lang["login_logout"] = "";
$lang["login_migration_needed"] = "";
$lang["login_password"] = "Lösenord";
$lang["login_username"] = "Användarnamn";
$lang["login_welcome"] = "";
