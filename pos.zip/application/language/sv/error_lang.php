<?php 

$lang["error_no_permission_module"] = "Du har inte rättigheter till modulen";
$lang["error_unknown"] = "Oväntat fel";
