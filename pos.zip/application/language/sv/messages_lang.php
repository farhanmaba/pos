<?php 

$lang["messages_first_name"] = "Förnamn";
$lang["messages_last_name"] = "Efternamn";
$lang["messages_message"] = "Meddelande";
$lang["messages_message_placeholder"] = "Ditt meddelande här...";
$lang["messages_message_required"] = "Meddelande krävs";
$lang["messages_multiple_phones"] = "(vid flera mottagare, avdela mobilnummer med komma)";
$lang["messages_phone"] = "Telefonnummer";
$lang["messages_phone_number_required"] = "Telefonnummer krävs";
$lang["messages_phone_placeholder"] = "Mobiltelefonnummer...";
$lang["messages_sms_send"] = "Skicka SMS";
$lang["messages_successfully_sent"] = "Meddelandet skickat till: ";
$lang["messages_unsuccessfully_sent"] = "Meddelandet skickades ej till: ";
