<?php 

$lang["datepicker_all_time"] = "All Tid";
$lang["datepicker_apply"] = "Skicka";
$lang["datepicker_cancel"] = "Avbryt";
$lang["datepicker_custom"] = "Anpassa";
$lang["datepicker_from"] = "Från";
$lang["datepicker_last_30"] = "Senaste 30 dagar";
$lang["datepicker_last_7"] = "Senaste 7 dagar";
$lang["datepicker_last_financial_year"] = "Senaste bokföringsår";
$lang["datepicker_last_month"] = "Senaste månaden";
$lang["datepicker_last_year"] = "Senaste året";
$lang["datepicker_same_month_last_year"] = "Samma månad föregående år";
$lang["datepicker_same_month_to_same_day_last_year"] = "Samma månad till dag förra året";
$lang["datepicker_this_financial_year"] = "Nuvarande bokföringsår";
$lang["datepicker_this_month"] = "Nuvarande månad";
$lang["datepicker_this_year"] = "Nuvarande år";
$lang["datepicker_to"] = "Till";
$lang["datepicker_today"] = "Idag";
$lang["datepicker_today_last_year"] = "Idag föregående år";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "I går";
