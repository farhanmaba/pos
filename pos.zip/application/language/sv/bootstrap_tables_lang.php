<?php 

$lang["tables_all"] = "alla";
$lang["tables_columns"] = "Kolumner";
$lang["tables_hide_show_pagination"] = "Dölj/visa sida";
$lang["tables_loading"] = "Laddar, ha tålamod...";
$lang["tables_page_from_to"] = "Visar {0} till {1} av {2} rader";
$lang["tables_refresh"] = "Ladda om";
$lang["tables_rows_per_page"] = "{0} rader per sida";
$lang["tables_toggle"] = "Växla";
