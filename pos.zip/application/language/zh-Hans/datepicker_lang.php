<?php 

$lang["datepicker_all_time"] = "全部";
$lang["datepicker_apply"] = "Apply";
$lang["datepicker_cancel"] = "取消銷售";
$lang["datepicker_custom"] = "Custom";
$lang["datepicker_from"] = "From";
$lang["datepicker_last_30"] = "過去七天";
$lang["datepicker_last_7"] = "過去七天";
$lang["datepicker_last_financial_year"] = "";
$lang["datepicker_last_month"] = "上個月";
$lang["datepicker_last_year"] = "去年";
$lang["datepicker_same_month_last_year"] = "Same Month Last Year";
$lang["datepicker_same_month_to_same_day_last_year"] = "Same Month To Same Day Last Year";
$lang["datepicker_this_financial_year"] = "";
$lang["datepicker_this_month"] = "這個月";
$lang["datepicker_this_year"] = "今年";
$lang["datepicker_to"] = "To";
$lang["datepicker_today"] = "今天";
$lang["datepicker_today_last_year"] = "Today Last Year";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "昨天";
