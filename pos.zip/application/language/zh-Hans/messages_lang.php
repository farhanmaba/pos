<?php
$lang["messages_first_name"] = "名";
$lang["messages_last_name"] = "姓";
$lang["messages_message"] = "Message";
$lang["messages_message_placeholder"] = "Your Message here...";
$lang["messages_message_required"] = "Message required";
$lang["messages_multiple_phones"] = "(In case of multiple recipients, enter mobile numbers separated by commas)";
$lang["messages_phone"] = "电话号码";
$lang["messages_phone_number_required"] = "电话号码是比填的";
$lang["messages_phone_placeholder"] = "Mobile Number(s) here...";
$lang["messages_sms_send"] = "Send SMS";
$lang["messages_successfully_sent"] = "信息成功发送到 ";
$lang["messages_unsuccessfully_sent"] = "Message unsuccessfully sent to: ";
