<?php
$lang["login_gcaptcha"] = "Nie jestem robotem.";
$lang["login_go"] = "Idź";
$lang["login_invalid_gcaptcha"] = "Udowodnij, że nie jesteś robotem.";
$lang["login_invalid_installation"] = "Instalacja nie jest poprawna, sprawdź swój plik php.ini.";
$lang["login_invalid_username_and_password"] = "Niepoprawna nazwa użytkownika i/lub hasło.";
$lang["login_login"] = "Zaloguj";
$lang["login_logout"] = "Wyloguj";
$lang["login_migration_needed"] = "Migracja bazy danych do %1 zacznie się po zalogowaniu.";
$lang["login_password"] = "Hasło";
$lang["login_username"] = "Nazwa użytkownika";
$lang["login_welcome"] = "Witaj w %1!";
