<?php
$lang["messages_first_name"] = "Pierwsze imię";
$lang["messages_last_name"] = "Nazwisko";
$lang["messages_message"] = "Wiadomość";
$lang["messages_message_placeholder"] = "Twoja wiadomość tutaj...";
$lang["messages_message_required"] = "Wiadomość wymagana";
$lang["messages_multiple_phones"] = "(W przypadku wielu odbiorców, wpisz numery telefonów oddzielone przecinkami)";
$lang["messages_phone"] = "Numer telefonu";
$lang["messages_phone_number_required"] = "Numer telefonu wymagany";
$lang["messages_phone_placeholder"] = "Numer(y) telefonu tutaj...";
$lang["messages_sms_send"] = "Wyślij SMS";
$lang["messages_successfully_sent"] = "Wiadomość pomyślnie wysłana do: ";
$lang["messages_unsuccessfully_sent"] = "Wiadomość nie została wysłana z powodzeniem do: ";
