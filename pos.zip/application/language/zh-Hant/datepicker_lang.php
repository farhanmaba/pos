<?php 

$lang["datepicker_all_time"] = "全部";
$lang["datepicker_apply"] = "申請";
$lang["datepicker_cancel"] = "取消銷售";
$lang["datepicker_custom"] = "定制";
$lang["datepicker_from"] = "從";
$lang["datepicker_last_30"] = "過去七天";
$lang["datepicker_last_7"] = "過去七天";
$lang["datepicker_last_financial_year"] = "上一財政年度";
$lang["datepicker_last_month"] = "上個月";
$lang["datepicker_last_year"] = "去年";
$lang["datepicker_same_month_last_year"] = "去年同月";
$lang["datepicker_same_month_to_same_day_last_year"] = "去年同月同日";
$lang["datepicker_this_financial_year"] = "當前財政年度";
$lang["datepicker_this_month"] = "這個月";
$lang["datepicker_this_year"] = "今年";
$lang["datepicker_to"] = "To";
$lang["datepicker_today"] = "今天";
$lang["datepicker_today_last_year"] = "去年的今天";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "昨天";
