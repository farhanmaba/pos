<?php 

$lang["category_name_required"] = "費用類別名稱為必填";
$lang["expenses_categories_add_item"] = "新增類別";
$lang["expenses_categories_cannot_be_deleted"] = "不可刪除費用類別";
$lang["expenses_categories_category_id"] = "Id";
$lang["expenses_categories_confirm_delete"] = "你確定要刪除選擇的費用類別嗎？";
$lang["expenses_categories_confirm_restore"] = "你確定要還原選擇的費用類別嗎？";
$lang["expenses_categories_description"] = "類別說明";
$lang["expenses_categories_error_adding_updating"] = "新增或修改費用類別失敗";
$lang["expenses_categories_info"] = "費用類別資訊";
$lang["expenses_categories_name"] = "類別名稱";
$lang["expenses_categories_new"] = "新增類別";
$lang["expenses_categories_no_expenses_categories_to_display"] = "沒有可顯示的類別";
$lang["expenses_categories_none_selected"] = "尚未選擇費用類別";
$lang["expenses_categories_one_or_multiple"] = "費用類別";
$lang["expenses_categories_quantity"] = "數量";
$lang["expenses_categories_successful_adding"] = "新增費用類別成功";
$lang["expenses_categories_successful_deleted"] = "刪除費用類別成功";
$lang["expenses_categories_successful_updating"] = "修改費用類別成功";
$lang["expenses_categories_update"] = "修改類別";
