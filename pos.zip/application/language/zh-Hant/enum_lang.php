<?php 

$lang["enum_half_down"] = "減半";
$lang["enum_half_even"] = "半偶";
$lang["enum_half_five"] = "半五";
$lang["enum_half_odd"] = "半奇數";
$lang["enum_half_up"] = "半升";
$lang["enum_round_down"] = "無條件捨去";
$lang["enum_round_up"] = "無條件進位";
