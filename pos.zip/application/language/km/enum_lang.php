<?php
$lang["enum_half_down"] = "ត្រឹមពាក់កណ្ដាលចុះក្រោម";
$lang["enum_half_even"] = "ពាក់កណ្តាលគូ";
$lang["enum_half_five"] = "ពាក់កណ្តាលប្រាំ";
$lang["enum_half_odd"] = "ពាក់កណ្តាលសេស";
$lang["enum_half_up"] = "ពាក់កណ្តាលឡើងលើ";
$lang["enum_round_down"] = "បង្គត់ចុះ";
$lang["enum_round_up"] = "បង្គត់ឡើង";
