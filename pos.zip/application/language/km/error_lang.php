<?php
$lang["error_no_permission_module"] = "អ្នកមិនមានសិទ្ធដើម្បីចូលទៅ ផ្នែកនោះទេ";
$lang["error_unknown"] = "កំហុសមិនស្គាល់";
