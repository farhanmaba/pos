<?php
$lang["tables_all"] = "ទាំងអស់";
$lang["tables_columns"] = "ជួរឈរ";
$lang["tables_hide_show_pagination"] = "លាក់/បង្ហាញ ទំព័រ";
$lang["tables_loading"] = "កំពុងរៀបចំ, សូមរងចាំ...";
$lang["tables_page_from_to"] = "បង្ហាញពី {0} ដល់​ {1} នៃ​ {2} ជួរដេក";
$lang["tables_refresh"] = "ធ្វើអោយថ្មី";
$lang["tables_rows_per_page"] = "{0} ជួរដេក ក្នុងមួយទំព័រ";
$lang["tables_toggle"] = "បិទបើក";
