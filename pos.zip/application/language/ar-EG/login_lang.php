<?php
$lang["login_gcaptcha"] = "أنا لست بوت.";
$lang["login_go"] = "البدء";
$lang["login_invalid_gcaptcha"] = "يرجى التأكيد على أنك لست روبوتا.";
$lang["login_invalid_installation"] = "يوجد مشكلة بالتنصيب, الرجاء التحقق من ملف php.ini.";
$lang["login_invalid_username_and_password"] = "اسم مستخدم/كلمة سر غير صحيح.";
$lang["login_login"] = "دخول";
$lang["login_logout"] = "تسجيل خروج";
$lang["login_migration_needed"] = "سيبدأ ترحيل قاعدة البيانات إلى٪ 1 بعد تسجيل الدخول.";
$lang["login_password"] = "كلمة السر";
$lang["login_username"] = "اسم المستخدم";
$lang["login_welcome"] = "مرحباً بك في٪ 1!";
