<?php 

$lang["tables_all"] = "Tất cả";
$lang["tables_columns"] = "Các cột";
$lang["tables_hide_show_pagination"] = "Ẩn/hiện phân trang";
$lang["tables_loading"] = "Đang tải, vui lòng đợi...";
$lang["tables_page_from_to"] = "Đang hiển thị {0} đến {1} trên {2} dòng";
$lang["tables_refresh"] = "Làm mới lại";
$lang["tables_rows_per_page"] = "{0} dòng mỗi trang";
$lang["tables_toggle"] = "Bật/Tắt";
