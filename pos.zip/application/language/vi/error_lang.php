<?php 

$lang["error_no_permission_module"] = "Bạn không có thẩm quyền truy cập vào mô đun đó";
$lang["error_unknown"] = "Lỗi chưa biết";
