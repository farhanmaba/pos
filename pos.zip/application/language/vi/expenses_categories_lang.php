<?php 

$lang["category_name_required"] = "Trường tên Thể loại chi phí là bắt buộc";
$lang["expenses_categories_add_item"] = "Thêm thể loại";
$lang["expenses_categories_cannot_be_deleted"] = "Không thể xóa Thể loại Chi phí";
$lang["expenses_categories_category_id"] = "Mã số";
$lang["expenses_categories_confirm_delete"] = "Bạn chắc chắn muốn xóa các Thể loại chi phí được chọn không?";
$lang["expenses_categories_confirm_restore"] = "Bạn có thực sự muốn hoàn nguyên lại thể loại phí đã chọn không?";
$lang["expenses_categories_description"] = "Mô tả Thể loại";
$lang["expenses_categories_error_adding_updating"] = "Lỗi khi thêm/cập nhật Thể loại chi phí";
$lang["expenses_categories_info"] = "Thông tin Thể loại chi phí";
$lang["expenses_categories_name"] = "Tên thể loại";
$lang["expenses_categories_new"] = "Thể loại mới";
$lang["expenses_categories_no_expenses_categories_to_display"] = "Không có thể loại nào để hiển thị";
$lang["expenses_categories_none_selected"] = "Bạn chưa chọn bất kỳ một Thể loại chi phí nào để mà sửa";
$lang["expenses_categories_one_or_multiple"] = "Thể loại chi phí";
$lang["expenses_categories_quantity"] = "Số lượng";
$lang["expenses_categories_successful_adding"] = "Thêm thành công Thể loại chi phí";
$lang["expenses_categories_successful_deleted"] = "Xóa thành công Thể loại chi phí";
$lang["expenses_categories_successful_updating"] = "Cập nhật thành công Thể loại chi phí";
$lang["expenses_categories_update"] = "Cập nhật thể loại";
