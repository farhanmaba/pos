<?php 

$lang["suppliers_account_number"] = "Số hiệu tài khoản";
$lang["suppliers_agency_name"] = "Tên đại lý";
$lang["suppliers_cannot_be_deleted"] = "Không thể xóa các Nhà cung cấp đã chọn. Một hay nhiều có Bán hàng.";
$lang["suppliers_category"] = "Thể loại";
$lang["suppliers_company_name"] = "Tên công ty";
$lang["suppliers_company_name_required"] = "Trường tên công ty là bắt buộc.";
$lang["suppliers_confirm_delete"] = "Bạn chắc chắn muốn xóa các Nhà cung cấp được chọn không?";
$lang["suppliers_confirm_restore"] = "Bạn chắc chắn muốn hoàn lại các Nhà cung cấp được chọn không?";
$lang["suppliers_cost"] = "Nhà cung ứng giá";
$lang["suppliers_error_adding_updating"] = "Gặp lỗi khi cập nhật hay thêm Nhà cung cấp.";
$lang["suppliers_goods"] = "Nhà cung ứng hàng hóa";
$lang["suppliers_new"] = "Nhà cung cấp mới";
$lang["suppliers_none_selected"] = "Bạn chưa chọn Nhà cung cấp để xóa.";
$lang["suppliers_one_or_multiple"] = "Nhà cung cấp";
$lang["suppliers_successful_adding"] = "Bạn đã thêm Nhà cung cấp thành công";
$lang["suppliers_successful_deleted"] = "Bạn đã xóa thành công";
$lang["suppliers_successful_updating"] = "Bạn đã cập nhật Nhà cung cấp thành công";
$lang["suppliers_supplier"] = "Nhà cung cấp";
$lang["suppliers_supplier_id"] = "Mã số";
$lang["suppliers_tax_id"] = "Mã số thuế";
$lang["suppliers_update"] = "Cập nhật Nhà cung cấp";
