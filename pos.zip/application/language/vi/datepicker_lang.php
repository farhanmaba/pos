<?php 

$lang["datepicker_all_time"] = "Toàn bộ thời gian";
$lang["datepicker_apply"] = "Áp dụng";
$lang["datepicker_cancel"] = "Thôi";
$lang["datepicker_custom"] = "Tùy chọn";
$lang["datepicker_from"] = "Từ";
$lang["datepicker_last_30"] = "30 ngày gần đây";
$lang["datepicker_last_7"] = "7 ngày gần đây";
$lang["datepicker_last_financial_year"] = "Năm tài chính trước";
$lang["datepicker_last_month"] = "Tháng trước";
$lang["datepicker_last_year"] = "Năm ngoái";
$lang["datepicker_same_month_last_year"] = "Cùng tháng năm ngoái";
$lang["datepicker_same_month_to_same_day_last_year"] = "Cùng tháng cùng ngày năm ngoái";
$lang["datepicker_this_financial_year"] = "Năm tài chính hiện tại";
$lang["datepicker_this_month"] = "Tháng này";
$lang["datepicker_this_year"] = "Năm nay";
$lang["datepicker_to"] = "Đến";
$lang["datepicker_today"] = "Hôm nay";
$lang["datepicker_today_last_year"] = "Hôm nay của năm ngoái";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "Hôm qua";
