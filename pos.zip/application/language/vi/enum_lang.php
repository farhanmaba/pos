<?php 

$lang["enum_half_down"] = "0,5 làm tròn xuống";
$lang["enum_half_even"] = "0,5 dương làm tròn lên, âm xuống";
$lang["enum_half_five"] = "Một phần tư";
$lang["enum_half_odd"] = "0,5 cắt phần lẻ";
$lang["enum_half_up"] = "0,5 làm tròn lên";
$lang["enum_round_down"] = "Làm tròn xuống";
$lang["enum_round_up"] = "Làm tròn lên";
