<?php
$lang["login_gcaptcha"] = "Tôi không phải là robot.";
$lang["login_go"] = "Đăng nhập";
$lang["login_invalid_gcaptcha"] = "Xin vui lòng xác nhận bạn không phải là robot.";
$lang["login_invalid_installation"] = "Phần cài đặt chưa đúng, kiểm tra tập tin php.ini của bạn.";
$lang["login_invalid_username_and_password"] = "Tài khoản hoặc mật khẩu không hợp lệ.";
$lang["login_login"] = "Đăng nhập";
$lang["login_logout"] = "Đăng xuất";
$lang["login_migration_needed"] = "Di chuyển cơ sở dữ liệu sang %1 sẽ được bắt đầu sau khi đăng nhập.";
$lang["login_password"] = "Mật khẩu";
$lang["login_username"] = "Tài khoản";
$lang["login_welcome"] = "Chào mừng đến với %1!";
